const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const helmet = require('helmet');
const { Server } = require('socket.io');
const bot = require('./bot');

const app = express();
app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const LOG_FILE = path.join(DATA_DIR, 'logs.txt');

// default config
let config = {
  adminFacebookID: "",
  cookieFile: null,
  abuseFile: null,
  botRunning: false,
  nicknameLock: {},
  groupNameLock: {}
};

// load or create config
try {
  if (fs.existsSync(CONFIG_FILE)) {
    const raw = fs.readFileSync(CONFIG_FILE, 'utf8');
    config = Object.assign(config, JSON.parse(raw || "{}"));
  } else {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
  }
} catch (e) {
  console.error('Failed to load config', e);
}

function saveConfig(){ fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8'); }

function log(msg){
  const time = new Date().toLocaleString();
  const line = `[${time}] ${msg}\n`;
  fs.appendFileSync(LOG_FILE, line);
  try { io.emit('log', line); } catch(e){}
  console.log(line.trim());
}

// multer setup
const upload = multer({ dest: UPLOADS_DIR });

// serve static UI
app.use('/', express.static(path.join(__dirname, 'public')));

// API endpoints
app.post('/upload/cookie', upload.single('cookiefile'), (req,res)=>{
  if(req.file){
    const dest = path.join(DATA_DIR, 'cookie' + path.extname(req.file.originalname));
    fs.renameSync(req.file.path, dest);
    config.cookieFile = dest;
    saveConfig();
    log('Cookie uploaded: ' + path.basename(dest));
    return res.json({ ok:true, file: path.basename(dest)});
  }
  res.status(400).json({ ok:false });
});

app.post('/upload/abuse', upload.single('abusefile'), (req,res)=>{
  if(req.file){
    const dest = path.join(DATA_DIR, 'abuse.txt');
    fs.renameSync(req.file.path, dest);
    config.abuseFile = dest;
    saveConfig();
    log('Abuse file uploaded: ' + path.basename(dest));
    return res.json({ ok:true, file: path.basename(dest)});
  }
  res.status(400).json({ ok:false });
});

app.post('/api/settings', (req,res)=>{
  const { adminFacebookID } = req.body;
  config.adminFacebookID = adminFacebookID || config.adminFacebookID;
  saveConfig();
  log('Settings updated.');
  res.json({ ok:true, config });
});

app.post('/api/bot/:action', (req,res)=>{
  const action = req.params.action;
  if(action === 'start'){
    if(!config.adminFacebookID) return res.status(400).json({ ok:false, error: 'Set Admin Facebook ID first.'});
    config.botRunning = true;
    saveConfig();
    bot.start(config, log, io);
    log('Bot started via panel.');
    return res.json({ ok:true });
  } else if(action === 'stop'){
    config.botRunning = false;
    saveConfig();
    bot.stop();
    log('Bot stopped via panel.');
    return res.json({ ok:true });
  }
  res.status(400).json({ ok:false });
});

app.post('/api/command', (req,res)=>{
  const { adminID, command, args } = req.body;
  if(!adminID || String(adminID) !== String(config.adminFacebookID)){
    return res.status(403).json({ ok:false, error: 'Only configured admin can run commands.'});
  }
  switch((command||'').toLowerCase()){
    case 'tid': {
      const tid = '1000' + Math.floor(Math.random()*9000);
      log(`TID requested -> ${tid}`);
      return res.json({ ok:true, tid });
    }
    case 'help': {
      log('Help requested');
      return res.json({ ok:true, help: bot.getHelp()});
    }
    default:
      log(`Unknown command: ${command}`);
      return res.status(400).json({ ok:false, error:'Unknown command' });
  }
});

// socket logs
io.on('connection', socket=>{
  try{
    const raw = fs.existsSync(LOG_FILE) ? fs.readFileSync(LOG_FILE,'utf8') : '';
    const lines = raw.split('\n').filter(Boolean).slice(-200).join('\n') + '\n';
    socket.emit('log', lines);
  }catch(e){}
});

// start server
server.listen(PORT, ()=>{
  console.log(`Panel running on http://localhost:${PORT}`);
  log('Control panel ready. Server started.');
});
