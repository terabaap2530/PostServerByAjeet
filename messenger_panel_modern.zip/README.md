# Messenger Bot Panel (Modern UI) - Demo (Simulated)

This is a demo control panel for a Messenger Group Name Lock bot. It includes:
- Modern Bootstrap UI (public/index.html)
- Server with endpoints to upload cookie/abuse files, save settings, start/stop simulated bot
- Socket.io live logs

IMPORTANT: This is a SIMULATION and does NOT connect to Facebook. Hooking into Facebook automatically requires using official APIs or user-provided libraries and credentials (and may violate platform policies). Use this panel to test and later integrate real bot logic in `bot.js`.

Run locally:
1. npm install
2. npm start
3. Open http://localhost:3000
