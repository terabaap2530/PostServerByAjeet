let interval = null;
let state = { running:false, config:null };

function start(configObj, logFn, io){
  if(interval) clearInterval(interval);
  state.running = true;
  state.config = configObj;
  logFn('Simulated bot: started (no real FB connection).');
  io.emit('bot-status', { running:true });
  interval = setInterval(()=>{
    const now = new Date().toLocaleTimeString();
    logFn(`Simulated check at ${now} — groupNameLock: ${JSON.stringify(state.config.groupNameLock||{})}`);
    io.emit('bot-event', { time: now, msg: 'Simulated check completed' });
  }, 15000);
}

function stop(){
  if(interval) clearInterval(interval);
  state.running = false;
  interval = null;
}

function getHelp(){
  return [
    '!help - show commands',
    '!tid - generate fake thread id'
  ].join('\n');
}

module.exports = { start, stop, getHelp };
